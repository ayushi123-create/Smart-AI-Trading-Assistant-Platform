# Stock Trading Journal

A PHP & MySQL based Trading Journal web application with dashboard analytics, trade tracking, and performance analysis.

---

## 🚀 Features
- User authentication (Login / Logout)
- Add, edit, and delete trades
- Trade history tracking
- Daily, weekly, and monthly analysis
- Profit & loss analytics
- Interactive charts using Chart.js
- Responsive UI with Bootstrap

---

## 🛠️ Technologies Used
- PHP
- MySQL
- HTML, CSS
- Bootstrap 5
- JavaScript
- Chart.js

---

## ⚙️ Installation & Setup

1. Install **XAMPP** or **WAMP**
2. Clone the repository or download ZIP
3. Move project folder to:
4. Create a database named:
5. Import the provided SQL file into phpMyAdmin
6. Update database credentials in:
7. Start Apache & MySQL
8. Open browser and visit:
