<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";
require_once "../includes/header.php";

$user_id = (int) $_SESSION['user_id'];

$from = $_GET['from'] ?? null;
$to   = $_GET['to'] ?? null;

$dateCondition = '';
if ($from && $to) {
    $dateCondition = " AND trade_date BETWEEN '$from' AND '$to' ";
} elseif ($from) {
    $dateCondition = " AND trade_date >= '$from' ";
} elseif ($to) {
    $dateCondition = " AND trade_date <= '$to' ";
}



$labels = [];
$data   = [];

$result = mysqli_query($conn, "
    SELECT YEAR(trade_date) AS y,
           WEEK(trade_date, 1) AS w,
           SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY y, w
    ORDER BY y, w
");

while ($row = mysqli_fetch_assoc($result)) {
    $labels[] = $row['y'] . '-W' . $row['w'];
    $data[]   = (float)$row['total'];
}



$best = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT stock_name, SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY stock_name
    ORDER BY total DESC
    LIMIT 1
"));

$worst = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT stock_name, SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY stock_name
    ORDER BY total ASC
    LIMIT 1
"));
?>


<div class="content">

    <h2 class="mb-4">Weekly Analysis</h2>

    
    <form method="GET" class="row g-2 mb-3">
        <div class="col-auto">
            <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
        </div>
        <div class="col-auto">
            <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
        </div>
        <div class="col-auto">
            <button class="btn btn-primary">Filter</button>
        </div>
    </form>

    
    <a href="export_csv.php?type=weekly&from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>"
       class="btn btn-success mb-4">
        Export CSV
    </a>

    
    <div class="card shadow-sm mb-4 w-100">
        <div class="card-body">
            <h5 class="mb-3">Weekly Profit / Loss</h5>
            <div style="width:100%; height:450px;">
                <canvas id="weeklyChart"></canvas>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h6 class="text-success">Best Stock</h6>
                    <h5>
                        <?= htmlspecialchars($best['stock_name'] ?? 'N/A') ?>
                        (<?= number_format($best['total'] ?? 0, 2) ?>)
                    </h5>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h6 class="text-danger">Worst Stock</h6>
                    <h5>
                        <?= htmlspecialchars($worst['stock_name'] ?? 'N/A') ?>
                        (<?= number_format($worst['total'] ?? 0, 2) ?>)
                    </h5>
                </div>
            </div>
        </div>
    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const ctx = document.getElementById('weeklyChart').getContext('2d');

new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Profit / Loss',
            data: <?= json_encode($data) ?>,
            fill: true,
            backgroundColor: context =>
                context.raw >= 0
                    ? 'rgba(25,135,84,0.25)'
                    : 'rgba(220,53,69,0.25)',
            borderColor: '#0d6efd',
            tension: 0.4,
            borderWidth: 3,
            pointRadius: 4,
            pointBackgroundColor: context =>
                context.raw >= 0
                    ? '#198754'
                    : '#dc3545',
            pointBorderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>

<?php require_once "../includes/footer.php"; ?>
