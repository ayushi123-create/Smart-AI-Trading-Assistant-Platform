<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";
require_once "../includes/header.php";

$user_id = (int) $_SESSION['user_id'];

$from = $_GET['from'] ?? null;
$to   = $_GET['to'] ?? null;

$dateCondition = '';
if ($from && $to) {
    $dateCondition = " AND trade_date BETWEEN '$from' AND '$to' ";
} elseif ($from) {
    $dateCondition = " AND trade_date >= '$from' ";
} elseif ($to) {
    $dateCondition = " AND trade_date <= '$to' ";
}


$labels = [];
$data   = [];

$result = mysqli_query($conn, "
    SELECT trade_date AS d, SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY d
    ORDER BY d
");

while ($row = mysqli_fetch_assoc($result)) {
    $labels[] = $row['d'];
    $data[]   = (float)$row['total'];
}



$best = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT stock_name, SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY stock_name
    ORDER BY total DESC
    LIMIT 1
"));

$worst = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT stock_name, SUM(profit_loss) AS total
    FROM trades
    WHERE user_id = $user_id $dateCondition
    GROUP BY stock_name
    ORDER BY total ASC
    LIMIT 1
"));
?>

<div class="content">

    <h2 class="mb-4">Daily Analysis</h2>

    <form method="GET" class="row g-2 mb-3">
        <div class="col-auto">
            <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
        </div>
        <div class="col-auto">
            <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
        </div>
        <div class="col-auto">
            <button class="btn btn-primary">Filter</button>
        </div>
    </form>

    <a href="export_csv.php?type=daily&from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>"
       class="btn btn-success mb-4">Export CSV</a>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5 class="mb-3">Daily Profit / Loss</h5>
            <div style="height:450px;">
                <canvas id="dailyChart"></canvas>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h6 class="text-success">Best Stock</h6>
                    <h5><?= htmlspecialchars($best['stock_name'] ?? 'N/A') ?>
                        (<?= number_format($best['total'] ?? 0, 2) ?>)</h5>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h6 class="text-danger">Worst Stock</h6>
                    <h5><?= htmlspecialchars($worst['stock_name'] ?? 'N/A') ?>
                        (<?= number_format($worst['total'] ?? 0, 2) ?>)</h5>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('dailyChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Profit / Loss',
            data: <?= json_encode($data) ?>,
            fill: true,
            borderWidth: 3,
            tension: 0.4
        }]
    },
    options: { maintainAspectRatio: false }
});
</script>

<?php require_once "../includes/footer.php"; ?>
