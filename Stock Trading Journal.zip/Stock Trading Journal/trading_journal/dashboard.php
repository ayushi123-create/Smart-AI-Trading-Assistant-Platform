<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trading Journal Pro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont;
        }

        .navbar {
            background: transparent;
            padding: 20px 0;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 22px;
        }

        
        .hero {
            min-height: 100vh;
            background: linear-gradient(135deg, #0f172a, #020617);
            color: white;
            display: flex;
            align-items: center;
        }

        .hero h1 {
            font-size: 46px;
            font-weight: 700;
        }

        .hero p {
            color: #cbd5f5;
            max-width: 520px;
        }

        .hero .btn-primary {
            padding: 12px 28px;
            font-weight: 600;
            border-radius: 8px;
        }

        .hero .btn-outline-light {
            padding: 12px 28px;
            border-radius: 8px;
        }

        
        .stats {
            background: #020617;
            color: white;
            padding: 40px 0;
        }

        .stat-box h4 {
            font-weight: 700;
        }

        
        .features {
            padding: 80px 0;
        }

        .feature-card {
            border-radius: 14px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            height: 100%;
        }
    </style>
</head>

<body>


<nav class="navbar navbar-expand-lg navbar-dark position-absolute w-100">
    <div class="container">
        <a class="navbar-brand" href="#">📊 TradingJournal Pro</a>

        <div class="ms-auto">
            <a href="auth/login.php" class="btn btn-outline-light me-2">Login</a>
            <a href="auth/register.php" class="btn btn-warning">Sign Up Free</a>
        </div>
    </div>
</nav>

<section class="hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1>Elevate Your <span class="text-warning">Trading</span><br>Performance</h1>
                <p class="mt-3">
                    Advanced trading journal to track, analyze, and improve your trading strategy.
                    Identify patterns, eliminate mistakes, and increase profitability.
                </p>

                <div class="mt-4">
                    <a href="auth/register.php" class="btn btn-primary me-3">Start Free Trial</a>
                    <a href="#features" class="btn btn-outline-light">Explore Features</a>
                </div>

                <div class="mt-4 text-warning">
                    ⭐⭐⭐⭐⭐ <small class="text-light">Rated by 2,500+ traders</small>
                </div>
            </div>

            <div class="col-md-5 text-center">
                <img src="https://cdn-icons-png.flaticon.com/512/3144/3144456.png"
                     alt="Trading"
                     class="img-fluid"
                     style="max-width: 320px;">
            </div>
        </div>
    </div>
</section>


<section class="stats text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-3 stat-box">
                <h4>15+</h4>
                <p>Active Traders</p>
            </div>
            <div class="col-md-3 stat-box">
                <h4>2K+</h4>
                <p>Trades Logged</p>
            </div>
            <div class="col-md-3 stat-box">
                <h4>47%</h4>
                <p>Avg Improvement</p>
            </div>
            <div class="col-md-3 stat-box">
                <h4>98%</h4>
                <p>Satisfaction Rate</p>
            </div>
        </div>
    </div>
</section>


<section class="features" id="features">
    <div class="container">
        <h2 class="text-center mb-5">Powerful Features for Serious Traders</h2>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <h5>📈 Advanced Analytics</h5>
                    <p>
                        Deep insights into your trading performance with customizable reports,
                        charts, and metrics.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <h5>⚡ Real-time Sync</h5>
                    <p>
                        Automatically sync trades and never miss a trade again.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <h5>🤖 AI-Powered Insights</h5>
                    <p>
                        Detect behavioral patterns and get smart recommendations to improve performance.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

</body>
</html>
