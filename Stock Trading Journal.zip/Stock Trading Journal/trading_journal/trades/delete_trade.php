<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once __DIR__ . "/../config/db.php";

if (!isset($_GET['id'])) {
    header("Location: ../dashboard/index.php");
    exit;
}

$trade_id = (int) $_GET['id'];
$user_id  = (int) $_SESSION['user_id'];

$query = "DELETE FROM trades WHERE id=$trade_id AND user_id=$user_id";

if (mysqli_query($conn, $query)) {
    header("Location: ../dashboard/index.php");
    exit;
} else {
    echo "Failed to delete trade!";
}
