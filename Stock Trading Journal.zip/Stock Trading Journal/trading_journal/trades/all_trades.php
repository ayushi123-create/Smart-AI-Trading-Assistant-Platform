<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/header.php";

$user_id = (int) $_SESSION['user_id'];

if (isset($_GET['delete'])) {
    $trade_id = (int) $_GET['delete'];
    $delete_query = "DELETE FROM trades WHERE id = $trade_id AND user_id = $user_id";
    mysqli_query($conn, $delete_query);
    header("Location: all_trades.php");
    exit;
}


$query = "SELECT * FROM trades WHERE user_id = $user_id ORDER BY trade_date DESC";
$result = mysqli_query($conn, $query);
?>


<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">📊 All Trades</h3>

    
    <a href="add_trade.php" class="btn btn-success">
        ➕ Add New Trade
    </a>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">

        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Stock</th>
                <th>Buy Price</th>
                <th>Sell Price</th>
                <th>Quantity</th>
                <th>Profit/Loss</th>
                <th>Type</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php $i = 1; while ($trade = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $trade['trade_date'] ?></td>
                        <td><?= htmlspecialchars($trade['stock_name']) ?></td>
                        <td><?= $trade['buy_price'] ?></td>
                        <td><?= $trade['sell_price'] ?></td>
                        <td><?= $trade['quantity'] ?></td>
                        <td><?= $trade['profit_loss'] ?></td>
                        <td><?= htmlspecialchars($trade['trade_type']) ?></td>
                        <td>
                            <a href="edit_trade.php?id=<?= $trade['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="all_trades.php?delete=<?= $trade['id'] ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure?');">
                               Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" class="text-center">
                        No trades found. Click "Add New Trade" to start.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>

    </table>
</div>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
