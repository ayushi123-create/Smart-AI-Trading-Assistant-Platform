<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/header.php";

if (!isset($_GET['id'])) {
    header("Location: all_trades.php");
    exit;
}

$trade_id = (int)$_GET['id'];
$user_id  = $_SESSION['user_id'];

// Fetch existing trade data
$query = "SELECT * FROM trades WHERE id = '$trade_id' AND user_id = '$user_id' LIMIT 1";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<div class='alert alert-danger'>Trade not found!</div>";
    exit;
}

$trade = mysqli_fetch_assoc($result);

if (isset($_POST['update_trade'])) {
    $trade_date = $_POST['trade_date'];
    $stock_name = mysqli_real_escape_string($conn, $_POST['stock_name']);
    $buy_price  = $_POST['buy_price'];
    $sell_price = $_POST['sell_price'];
    $quantity   = $_POST['quantity'];
    $trade_type = $_POST['trade_type'];

    $profit_loss = ($sell_price - $buy_price) * $quantity;

    $update_query = "
        UPDATE trades
        SET trade_date='$trade_date',
            stock_name='$stock_name',
            buy_price='$buy_price',
            sell_price='$sell_price',
            quantity='$quantity',
            profit_loss='$profit_loss',
            trade_type='$trade_type'
        WHERE id='$trade_id' AND user_id='$user_id'
    ";

    if (mysqli_query($conn, $update_query)) {
        header("Location: ../trades/all_trades.php");
        exit;
    } else {
        $error = "Failed to update trade!";
    }
}
?>

<h3 class="mb-4">✏️ Edit Trade</h3>

<?php if (isset($error)) { ?>
    <div class="alert alert-danger">
        <?php echo $error; ?>
    </div>
<?php } ?>

<form method="POST" class="card p-4 shadow-sm">

    <div class="mb-3">
        <label class="form-label">Trade Date</label>
        <input type="date" name="trade_date" class="form-control" value="<?php echo $trade['trade_date']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Stock Name</label>
        <input type="text" name="stock_name" class="form-control" value="<?php echo $trade['stock_name']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Buy Price</label>
        <input type="number" step="0.01" name="buy_price" class="form-control" value="<?php echo $trade['buy_price']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Sell Price</label>
        <input type="number" step="0.01" name="sell_price" class="form-control" value="<?php echo $trade['sell_price']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Quantity</label>
        <input type="number" name="quantity" class="form-control" value="<?php echo $trade['quantity']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Trade Type</label>
        <select name="trade_type" class="form-control" required>
            <option value="">Select Type</option>
            <option value="Buy" <?php if ($trade['trade_type'] == 'Buy') echo 'selected'; ?>>Buy</option>
            <option value="Sell" <?php if ($trade['trade_type'] == 'Sell') echo 'selected'; ?>>Sell</option>
        </select>
    </div>

    <div class="d-flex gap-2">
        <button type="submit" name="update_trade" class="btn btn-primary">Update Trade</button>
        <a href="../trades/all_trades.php" class="btn btn-secondary">Cancel</a>
    </div>

</form>

<?php require_once __DIR__ . "/../includes/footer.php"; ?>
