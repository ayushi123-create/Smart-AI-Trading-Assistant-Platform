<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/header.php";

if (isset($_POST['add_trade'])) {

    $user_id    = $_SESSION['user_id'];
    $trade_date = $_POST['trade_date'];
    $stock_name = mysqli_real_escape_string($conn, $_POST['stock_name']);
    $buy_price  = $_POST['buy_price'];
    $sell_price = $_POST['sell_price'];
    $quantity   = $_POST['quantity'];
    $trade_type = $_POST['trade_type']; // ✅ capture trade type

    $profit_loss = ($sell_price - $buy_price) * $quantity;

    $query = "
        INSERT INTO trades
        (user_id, trade_date, stock_name, trade_type, buy_price, sell_price, quantity, profit_loss)
        VALUES
        ('$user_id', '$trade_date', '$stock_name', '$trade_type', '$buy_price', '$sell_price', '$quantity', '$profit_loss')
    ";

    if (mysqli_query($conn, $query)) {
        header("Location: ../dashboard/index.php");
        exit;
    } else {
        $error = "Failed to add trade! " . mysqli_error($conn); // optional: show MySQL error
    }
}
?>
<h3 class="mb-4">➕ Add Trade</h3>

<?php if (isset($error)) { ?>
    <div class="alert alert-danger">
        <?php echo $error; ?>
    </div>
<?php } ?>

<form method="POST" class="card p-4 shadow-sm">

    <div class="mb-3">
        <label class="form-label">Trade Date</label>
        <input type="date" name="trade_date" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Stock Name</label>
        <input type="text" name="stock_name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Buy Price</label>
        <input type="number" step="0.01" name="buy_price" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Sell Price</label>
        <input type="number" step="0.01" name="sell_price" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Quantity</label>
        <input type="number" name="quantity" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Trade Type</label>
        <select name="trade_type" class="form-control" required>
            <option value="">Select Type</option>
            <option value="Buy">Buy</option>
            <option value="Sell">Sell</option>
        </select>
    </div>

    <div class="d-flex gap-2">
        <button type="submit" name="add_trade" class="btn btn-success">Save Trade</button>
        <a href="../dashboard/index.php" class="btn btn-secondary">Cancel</a>
    </div>

</form>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>
