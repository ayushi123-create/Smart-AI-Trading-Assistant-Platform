<?php
require_once "../includes/header.php";
require_once "../config/db.php";
require_once "../includes/sidebar.php";

$uid = $_SESSION['user_id'];
$res = $conn->query("SELECT * FROM trades WHERE user_id=$uid ORDER BY trade_date DESC");
?>

<table class="table">
<tr>
<th>Date</th><th>Instrument</th><th>P/L</th><th>Action</th>
</tr>
<?php while($t=$res->fetch_assoc()): ?>
<tr class="<?= $t['profit_loss']>=0?'table-success':'table-danger' ?>">
<td><?= $t['trade_date'] ?></td>
<td><?= $t['instrument'] ?></td>
<td><?= $t['profit_loss'] ?></td>
<td>
<a href="edit_trade.php?id=<?= $t['id'] ?>">Edit</a>
<a href="delete_trade.php?id=<?= $t['id'] ?>">Delete</a>
</td>
</tr>
<?php endwhile; ?>
</table>
