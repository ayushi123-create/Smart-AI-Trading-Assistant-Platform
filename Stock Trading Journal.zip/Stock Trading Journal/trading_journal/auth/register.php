<?php
session_start();
require_once "../config/db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // check email exists
    $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $message = "Email already registered!";
    } else {
        mysqli_query($conn, "
            INSERT INTO users (username, email, password)
            VALUES ('$name', '$email', '$password')
        ");
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    min-height: 100vh;
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    display: flex;
    align-items: center;
    justify-content: center;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 20px 40px rgba(0,0,0,.25);
}

.auth-header {
    background: #0d6efd;
    color: #fff;
    padding: 20px;
    text-align: center;
    border-radius: 12px 12px 0 0;
}

.auth-body {
    padding: 25px;
}

.form-control {
    height: 45px;
}

.btn-primary {
    height: 45px;
    font-weight: 600;
}
</style>
</head>

<body>

<div class="auth-card">
    <div class="auth-header">
        <h4>Create Your Account</h4>
        <small>Start your trading journey</small>
    </div>

    <div class="auth-body">

        <?php if ($message): ?>
            <div class="alert alert-danger"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST">

            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button class="btn btn-primary w-100">Create Account</button>

        </form>

        <div class="text-center mt-3">
            Already have an account?
            <a href="login.php">Login</a>
        </div>

    </div>
</div>

</body>
</html>
