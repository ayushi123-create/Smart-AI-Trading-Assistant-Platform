<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trading Journal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            margin: 0;
            background: #f4f6f9;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto;
            overflow-x: hidden;
        }

        
        .sidebar {
            width: 220px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #0d6efd;
            padding: 20px;
            color: #fff;
        }

        .sidebar h5 {
            text-align: center;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 10px 12px;
            margin: 6px 0;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.2);
        }

        .logout {
            color: #ffc107;
        }

        /* MAIN CONTENT */
        .main {
            margin-left: 220px;
            padding: 25px;
            min-height: 100vh;
            width: calc(100% - 220px);
        }

        .stat-card {
            color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        canvas {
            max-width: 100% !important;
        }

        
        @media (max-width: 768px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            .main {
                margin-left: 0;
                width: 100%;
                padding: 20px;
            }
        }
    </style>
</head>

<body>


<div class="sidebar">
    <h5>Trading Journal</h5>
    <hr>
    <a href="../dashboard/index.php">📊 Dashboard</a>
    <a href="../trades/all_trades.php">📋 All Trades</a>
    <a href="../analysis/daily.php">📅 Daily</a>
    <a href="../analysis/weekly.php">📈 Weekly</a>
    <a href="../analysis/monthly.php">📊 Monthly</a>
    <hr>
    <a href="../auth/logout.php" class="logout">🚪 Logout</a>
</div>


<div class="main">
