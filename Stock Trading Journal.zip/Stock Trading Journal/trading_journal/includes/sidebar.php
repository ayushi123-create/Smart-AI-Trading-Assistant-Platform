<div class="list-group">
<a href="../dashboard/index.php" class="list-group-item">Dashboard</a>
<a href="../trades/add_trade.php" class="list-group-item">Add Trade</a>
<a href="../trades/index.php" class="list-group-item">My Trades</a>
<a href="../analysis/daily.php" class="list-group-item">Daily</a>
<a href="../analysis/weekly.php" class="list-group-item">Weekly</a>
<a href="../analysis/monthly.php" class="list-group-item">Monthly</a>
<a href="../export/export_csv.php" class="list-group-item">Export CSV</a>
<a href="../auth/logout.php" class="list-group-item text-danger">Logout</a>
</div>
