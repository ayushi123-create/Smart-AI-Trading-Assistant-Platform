<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}


include "../config/db.php";
include "../includes/header.php";

$user_id = $_SESSION['user_id'];



$result = $conn->query("SELECT COUNT(*) as total_trades FROM trades WHERE user_id = $user_id");
$totalTrades = $result->fetch_assoc()['total_trades'] ?? 0;


$result = $conn->query("SELECT SUM(profit_loss) as total_profit FROM trades WHERE user_id = $user_id");
$totalProfit = $result->fetch_assoc()['total_profit'] ?? 0;

$avgPL = $totalTrades > 0 ? round($totalProfit / $totalTrades, 2) : 0;


$result = $conn->query("SELECT COUNT(*) as wins FROM trades WHERE user_id = $user_id AND profit_loss > 0");
$wins = $result->fetch_assoc()['wins'] ?? 0;
$winRate = $totalTrades > 0 ? round(($wins / $totalTrades) * 100, 2) : 0;


$result = $conn->query("SELECT MAX(profit_loss) as best_trade FROM trades WHERE user_id = $user_id");
$bestTrade = $result->fetch_assoc()['best_trade'] ?? 0;


$result = $conn->query("SELECT MIN(profit_loss) as worst_trade FROM trades WHERE user_id = $user_id");
$worstTrade = $result->fetch_assoc()['worst_trade'] ?? 0;


$recentTrades = $conn->query("SELECT * FROM trades WHERE user_id = $user_id ORDER BY trade_date DESC LIMIT 5");



$profitData = [];
$labels = [];
$winCount = 0;
$lossCount = 0;

$currentMonth = date('Y-m'); // e.g., 2026-01
$result = $conn->query("SELECT trade_date, profit_loss FROM trades WHERE user_id=$user_id AND DATE_FORMAT(trade_date,'%Y-%m')='$currentMonth' ORDER BY trade_date ASC");

while ($row = $result->fetch_assoc()) {
    $labels[] = $row['trade_date'];
    $profitData[] = $row['profit_loss'];
    if ($row['profit_loss'] > 0) $winCount++;
    else $lossCount++;
}
?>

<div class="content">

    <h4 class="mb-4">📊 Dashboard Overview</h4>

    
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card shadow-sm text-white bg-primary">
                <div class="card-body">
                    <h6>Win Rate</h6>
                    <h4><?= $winRate ?>%</h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-sm text-white bg-success">
                <div class="card-body">
                    <h6>Total Profit</h6>
                    <h4>₹ <?= number_format($totalProfit) ?></h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-sm text-white bg-info">
                <div class="card-body">
                    <h6>Total Trades</h6>
                    <h4><?= $totalTrades ?></h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-sm text-white bg-warning">
                <div class="card-body">
                    <h6>Avg P/L</h6>
                    <h4>₹ <?= number_format($avgPL) ?></h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="mb-3">📈 Monthly P/L Trend</h6>
                    <div style="height:300px">
                        <canvas id="profitChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="mb-3">⚖ Trade Outcome</h6>
                    <div style="height:300px">
                        <canvas id="winLossChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Best & Worst Trades -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>🏆 Best Trade</h6>
                    <h4 class="text-success">₹ <?= number_format($bestTrade) ?></h4>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>⚠ Worst Trade</h6>
                    <h4 class="text-danger">₹ <?= number_format($worstTrade) ?></h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Trades -->
    <div class="card shadow-sm">
        <div class="card-body">
            <h6 class="mb-3">🕒 Recent Trades</h6>

            <table class="table table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Date</th>
                        <th>Stock</th>
                        <th>P/L</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($trade = $recentTrades->fetch_assoc()): ?>
                        <tr class="<?= $trade['profit_loss'] >= 0 ? 'table-success' : 'table-danger' ?>">
                            <td><?= $trade['trade_date'] ?></td>
                            <td><?= $trade['stock'] ?></td>
                            <td class="<?= $trade['profit_loss'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                <?= $trade['profit_loss'] >= 0 ? '+' : '' ?><?= number_format($trade['profit_loss']) ?>
                            </td>
                            <td>
                                <span class="badge <?= $trade['profit_loss'] >= 0 ? 'bg-success' : 'bg-danger' ?>">
                                    <?= $trade['profit_loss'] >= 0 ? 'Win' : 'Loss' ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>

new Chart(document.getElementById('profitChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Profit',
            data: <?= json_encode($profitData) ?>,
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});


new Chart(document.getElementById('winLossChart'), {
    type: 'doughnut',
    data: {
        labels: ['Wins', 'Losses'],
        datasets: [{
            data: [<?= $winCount ?>, <?= $lossCount ?>],
            backgroundColor: ['#198754','#dc3545']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>

<?php include "../includes/footer.php"; ?>
