import os
import pandas as pd
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
import re

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Global variables to simulate session aggregation for multiple CSV files
global_trade_df = pd.DataFrame()
current_trade_data = {}

def calculate_metrics(df):
    pnl_col = next((col for col in df.columns if 'pnl' in col.lower() or 'profit' in col.lower() or 'loss' in col.lower()), None)
    strategy_col = next((col for col in df.columns if 'strategy' in col.lower() or 'type' in col.lower()), None)
    date_col = next((col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()), None)

    total_trades = len(df)
    
    if pnl_col:
        df[pnl_col] = pd.to_numeric(df[pnl_col], errors='coerce')
        winning_trades = df[df[pnl_col] > 0]
        losing_trades = df[df[pnl_col] <= 0]
        total_profit = df[pnl_col].sum()
        win_rate = (len(winning_trades) / total_trades) * 100 if total_trades > 0 else 0
        
        worst_loss = df[pnl_col].min()
        worst_loss = worst_loss if worst_loss < 0 else 0
        
        avg_profit = df[pnl_col].mean()

        # Chart data: limit to latest 100
        chart_df = df.tail(100)
        chart_labels = [f"Trade {i+1}" for i in range(len(chart_df))]
        chart_data = chart_df[pnl_col].fillna(0).tolist()
    else:
         total_profit = win_rate = worst_loss = avg_profit = 0
         chart_labels = []
         chart_data = []

    best_strategy = "Unknown"
    if strategy_col and pnl_col:
        strategy_perf = df.groupby(strategy_col)[pnl_col].sum()
        if not strategy_perf.empty:
            best_strategy = strategy_perf.idxmax()
    elif strategy_col:
        best_strategy = df[strategy_col].mode()[0] if not df[strategy_col].mode().empty else "Unknown"
        
    best_day = "Unknown"
    if date_col and pnl_col:
        try:
            df['parsed_date'] = pd.to_datetime(df[date_col], errors='coerce')
            df['day_name'] = df['parsed_date'].dt.day_name()
            day_perf = df.groupby('day_name')[pnl_col].sum()
            if not day_perf.empty:
                best_day = day_perf.idxmax()
        except:
             best_day = "Data error"

    response_data = {
        'total_trades': total_trades,
        'total_profit': round(total_profit, 2),
        'win_rate': round(win_rate, 2),
        'best_strategy': str(best_strategy),
        'worst_loss': round(worst_loss, 2),
        'avg_profit': round(avg_profit, 2),
        'best_day': str(best_day),
        'chart_labels': chart_labels,
        'chart_data': chart_data
    }
    return response_data

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    global global_trade_df
    global current_trade_data
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            new_df = pd.read_csv(filepath)
            
            # Combine multiple CSVs
            global_trade_df = pd.concat([global_trade_df, new_df], ignore_index=True)
            
            # Recalculate metrics on aggregated data
            current_trade_data = calculate_metrics(global_trade_df)
            
            # Generate Smart Suggestion
            smart_suggestion = ""
            if current_trade_data['total_profit'] < 0:
                smart_suggestion = f"You are experiencing a net loss. Your worst loss was ${abs(current_trade_data['worst_loss'])}. Consider tightening your risk management and sticking to your best strategy ({current_trade_data['best_strategy']})."
            else:
                 smart_suggestion = f"Great work! You perform better in the '{current_trade_data['best_strategy']}' strategy. Consider focusing more on it to maximize your ${current_trade_data['avg_profit']} average profit per trade. Your best trading day seems to be {current_trade_data['best_day']}."
            
            current_trade_data['smart_suggestion_text'] = smart_suggestion
            
            return jsonify({'message': 'File appended successfully', 'data': current_trade_data})
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
            
    return jsonify({'error': 'Invalid file type. Please upload a CSV.'}), 400

@app.route('/api/chat', methods=['POST'])
def chat():
    global current_trade_data
    user_message = request.json.get('message', '').lower()
    
    response_msg = ""
    
    if not current_trade_data:
        if "rsi" in user_message:
            response_msg = "RSI (Relative Strength Index) is a momentum oscillator. Over 70 indicates overbought, under 30 indicates oversold. Please upload data so I can give you personalized advice!"
        else:
            response_msg = "Please upload a CSV file first so I can analyze your specific trades."
        return jsonify({'reply': response_msg})

    profit = current_trade_data.get('total_profit', 0)
    win_rate = current_trade_data.get('win_rate', 0)
    best_strat = current_trade_data.get('best_strategy', 'None')
    worst_loss = current_trade_data.get('worst_loss', 0)
    avg_profit = current_trade_data.get('avg_profit', 0)
    best_day = current_trade_data.get('best_day', 'None')

    # Smart Dynamic Logic Matching
    if re.search(r'win\s*rate', user_message):
        response_msg = f"Your exact win rate right now is {win_rate}% across {current_trade_data['total_trades']} total trades."
        if win_rate > 50:
            response_msg += " That's a profitable edge!"
    elif "best strategy" in user_message or "which strategy" in user_message:
        response_msg = f"According to your data, your most profitable strategy is '{best_strat}'. You should prioritize setups that match this strategy."
    elif "worst loss" in user_message or "biggest loss" in user_message:
        response_msg = f"Your worst recorded loss is ${abs(worst_loss)}. Ensure your stop-losses prevent drops of this magnitude in the future."
    elif "average" in user_message or "avg profit" in user_message:
        response_msg = f"Your average profit per trade is ${avg_profit}."
    elif "best day" in user_message or "which day" in user_message:
        response_msg = f"You seem to make the most profit on {best_day}s."
    elif "analyze" in user_message or "last trades" in user_message:
        response_msg = f"I've analyzed all your uploaded trades. Your win rate is {win_rate}% and your best strategy is {best_strat}. Your total PnL stands at ${profit}."
    elif "rsi" in user_message:
        response_msg = "RSI (Relative Strength Index) measures the speed of price movements (0-100). Keep an eye on RSI divergences on your 'Breakout' trades for better entries!"
    else:
        # Fallback dynamic smart responses
        response_msg = f"I'm continuously monitoring your ${profit} PnL curve. I recommend focusing on {best_day}s and utilizing the {best_strat} strategy more."

    return jsonify({'reply': response_msg})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
