let performanceChart = null;

document.addEventListener('DOMContentLoaded', () => {
    // Elements
    const fileUpload = document.getElementById('csv-upload');
    const uploadLabel = document.querySelector('.upload-btn');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const chatMessages = document.getElementById('chat-messages');
    const themeBtn = document.getElementById('theme-toggle');
    
    // Dashboard Elements
    const elTotalPnl = document.getElementById('total-pnl');
    const elWinRate = document.getElementById('win-rate');
    const elBestStrategy = document.getElementById('best-strategy');
    const elAvgProfit = document.getElementById('avg-profit');
    const elWorstLoss = document.getElementById('worst-loss');
    const elBestDay = document.getElementById('best-day');
    const elSmartSuggestion = document.getElementById('smart-suggestion-txt');

    // Theme Logic
    let isLightMode = localStorage.getItem('theme') === 'light';
    if (isLightMode) {
        document.body.classList.add('light-mode');
        themeBtn.textContent = '🌙 Dark Mode';
    }
    
    themeBtn.addEventListener('click', () => {
        isLightMode = !isLightMode;
        document.body.classList.toggle('light-mode', isLightMode);
        themeBtn.textContent = isLightMode ? '🌙 Dark Mode' : '☀️ Light Mode';
        localStorage.setItem('theme', isLightMode ? 'light' : 'dark');
        Chart.defaults.color = isLightMode ? '#475569' : '#94a3b8';
        if (performanceChart) performanceChart.update();
    });

    // Initialize Empty Chart
    Chart.defaults.color = isLightMode ? '#475569' : '#94a3b8';
    Chart.defaults.font.family = "'Inter', sans-serif";
    initChart([], []);

    // File Upload Handler (Supports multiple because of the endpoint appending)
    fileUpload.addEventListener('change', async (e) => {
        const files = e.target.files;
        if (!files || files.length === 0) return;

        uploadLabel.textContent = `⏳ Uploading...`;
        
        for (let i = 0; i < files.length; i++) {
            const formData = new FormData();
            formData.append('file', files[i]);

            try {
                const response = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (response.ok) {
                    updateDashboard(result.data);
                    if (i === files.length - 1) { // On last file
                        uploadLabel.textContent = `✅ Uploaded`;
                        uploadLabel.style.background = 'var(--success)';
                        setTimeout(() => {
                            uploadLabel.textContent = `📊 Upload Data (CSV)`;
                            uploadLabel.style.background = '';
                        }, 3000);
                        
                        addMessageToChat('AI Helper', `I've successfully processed and aggregated your latest uploaded data. I noticed your best strategy is ${result.data.best_strategy}. Ask me to analyze it!`, 'ai-message');
                    }
                } else {
                    uploadLabel.textContent = `❌ Failed`;
                }
            } catch (error) {
                console.error('Error uploading file:', error);
                uploadLabel.textContent = `❌ Error`;
            }
        }
    });

    // Chat Handler
    const sendMessage = async () => {
        const text = chatInput.value.trim();
        if (!text) return;

        addMessageToChat('You', text, 'user-message');
        chatInput.value = '';

        // Add typing indicator
        const typingId = 'typing-' + Date.now();
        addTypingIndicator(typingId);

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text })
            });
            const data = await response.json();
            
            // Remove typing and add response
            document.getElementById(typingId)?.remove();
            addMessageToChat('AI Helper', data.reply, 'ai-message');
        } catch (error) {
            document.getElementById(typingId)?.remove();
            addMessageToChat('System Error', 'Failed to connect to AI.', 'ai-message');
        }
    };

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    // Utility Functions
    function addMessageToChat(sender, text, className) {
        const div = document.createElement('div');
        div.className = `message ${className}`;
        
        // Add exact message text
        const textNode = document.createTextNode(text);
        div.appendChild(textNode);
        
        // Add timestamp
        const timeDiv = document.createElement('div');
        timeDiv.className = 'msg-timestamp';
        const now = new Date();
        timeDiv.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        div.appendChild(timeDiv);

        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function addTypingIndicator(id) {
        const div = document.createElement('div');
        div.className = `message ai-message typing-indicator`;
        div.id = id;
        div.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function updateDashboard(data) {
        // Update Stats
        elTotalPnl.textContent = `$${data.total_profit.toFixed(2)}`;
        elTotalPnl.className = `value ${data.total_profit >= 0 ? 'profit' : 'loss'}`;
        
        elWinRate.textContent = `${data.win_rate}%`;
        elBestStrategy.textContent = data.best_strategy;
        
        // New stats
        elAvgProfit.textContent = `$${data.avg_profit.toFixed(2)}`;
        elWorstLoss.textContent = `$${data.worst_loss.toFixed(2)}`;
        elBestDay.textContent = data.best_day;

        // Update Smart Suggestion from backend
        if (data.smart_suggestion_text) {
             elSmartSuggestion.textContent = data.smart_suggestion_text;
        }

        // Update Chart
        updateChart(data.chart_labels, data.chart_data);
    }

    function initChart(labels, data) {
        const ctx = document.getElementById('performanceChart').getContext('2d');
        
        performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Cumulative PnL',
                    data: data,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 3,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        grid: { color: 'rgba(148, 163, 184, 0.1)' } // use a neutral light alpha
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }

    function updateChart(labels, dataPoints) {
        let cumulative = 0;
        const cumulativeData = dataPoints.map(val => {
            cumulative += val;
            return cumulative;
        });

        performanceChart.data.labels = labels;
        performanceChart.data.datasets[0].data = cumulativeData;
        
        const isProfitable = cumulative >= 0;
        performanceChart.data.datasets[0].borderColor = isProfitable ? '#10b981' : '#ef4444';
        performanceChart.data.datasets[0].backgroundColor = isProfitable ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)';
        
        performanceChart.update();
    }
});
